<p>Ok, this was just a short demo to show you how you could use the <b>EGuider</b> extension in your next app.<br/>
That's all folks !</p>  