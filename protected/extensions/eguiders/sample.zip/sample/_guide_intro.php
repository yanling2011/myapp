<p><img src="images/guided.png" alt="guided" style="float:left;"/>
The <b>EGuiders</b> extension is a Yii wrapper for the excellent <a href="https://github.com/jeff-optimizely/Guiders-JS" target="_new">Guiders</a> JQuery plugin. It offers
a convenient way to guide your users in your web page,  focus on new features or simply provide help.</p>

