To use the sample page, copy all php files into a view folder, and
the css file into folder CSS at the root fo your web app.
