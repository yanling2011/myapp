<?php 
$this->widget('ext.eguiders.EGuider', array(
		'id'			=> 'intro',
		'next' 			=> 'position',
		'title'			=> 'Welcome',
		'buttons'		=> array(array('name'=>'Next')),
		'description' 	=> $this->renderPartial('_guide_intro',null,true),
		'overlay'		=> true,
		'xButton'		=> true,
		'show'			=> true
	)
);

$this->widget('ext.eguiders.EGuider', array(
		'id'			=> 'position',
		'next' 			=> 'sample',
		'title'			=> 'Positionning',		
		'buttons' 		=> array(
			array('name'=>'Next'),
		),
		'description' 	=>  $this->renderPartial('_guide_position',null,true),
		'overlay'		=> false,
		'attachTo' 		=> '#firstAttach',
		'position' 		=> 6,
		'xButton'		=> true,
		'onShow'		=> 'js:function(){guiders.hideAll();}',
	)
);


$this->widget('ext.eguiders.EGuider', array(
		'id'			=> 'sample',
		'title'			=> 'Sample',
		'next' 			=> 'api',
		'buttons' 		=> array(
			array('name'=>'Next'),
		),
		'description' 	=> $this->renderPartial('_guide_sample',null,true),
		'overlay'		=> false,
		'attachTo' 		=> '#sampleCode',
		'position' 		=> 11,
		'xButton'		=> true,		
	)
);

$this->widget('ext.eguiders.EGuider', array(
		'id'			=> 'api',
		'title'			=> 'Simple API',
		'next' 			=> 'scroll',
		'buttons' 		=> array(
			array('name'=>'Previous',	 'onclick'=> "js:function(){guiders.hideAll(); $('.highlight pre').hide(); guiders.show('sample');}"),
			array('name'=>'Show me more','onclick'=> "js:function(){guiders.next();}"),
			array('name'=>'Exit',		 'onclick'=> "js:function(){guiders.hideAll();}")
		),
		'description' 	=> $this->renderPartial('_guide_api',null,true),
		'overlay'		=> false,
		'attachTo' 		=> '#api',
		'position' 		=> 11,
		'xButton'		=> true,		
		'onShow' 		=> 'js:function(){ $(".highlight pre").show();}'
	)
);
$this->widget('ext.eguiders.EGuider', array(
		'id'			=> 'scroll',
		'title'			=> "It scrolls !!",
		'next'			=> 'style',
		'description' 	=> 'see ? see ? the page scroll so to display the guide ... nice<br/>'.
			'yes and also you can see that the "highlight" option does\'t work so well (no big deal).',
		'attachTo' 		=> '#sampleCode2',
		'position'		=> 6,
		'highlight'		=> '#sampleCode2',
		'buttons'		=> array(array('name'=>'Next')),
	)
);


$this->widget('ext.eguiders.EGuider', array(
		'id'			=> 'style',
		'title'			=> "Custom style is also available !",
		'next'			=> 'end',
		'description' 	=> "<b>Yes you can !</b> ... Simply register your own CSS style and choose a CSS class name "
			." that will be added to the parent enclosing DIV.",
		'classString' 	=> 'custom',
		'buttons' 		=> array(array('name'=>'Next')),
		'attachTo' 		=> '#sampleCode3',
		'position' 		=> 11,		
		'cssFile'		=> Yii::app()->baseUrl. '/css/custom_guiders.css',
		'classString' 	=> 'custom',
	)
);

$this->widget('ext.eguiders.EGuider', array(
		'id'			=> 'end',
		'title'			=> "That's it !",
		'buttons' 		=> array(array('name'=>'Close')),
		'description' 	=> $this->renderPartial('_guide_end',null,true),
		'overlay'		=> true,
	)
);
?>
<div id="firstAttach"></div>
<h1>Guiders</h1>
<h2>The Basic</h2>
<p>Guiders is a JQuery plugin that will guide user on a web page. Below is a basic example on how to create a guide. As you can see, the next button
on this guide will drive the user to another Guide with id set to 'second'.</p>
<div id="sampleCode">
<?php 
$this->beginWidget('system.web.widgets.CTextHighlighter',array(
	'language'=>'PHP',
	'showLineNumbers'=>false,
));
?>
$this->widget('ext.guiders.EGuider', array(
		'id'=> 'first',
		'next' => 'second',
		'title'=> 'Guider title',
		'buttons' => array(array('name'=>'Next')),
		'description' => '<b>here you should put some intresting text</b>',
		'overlay'=> true,
		'xButton'=>true,
		// look here !! 'show' is true, so that means this guider will be
		// automatically displayed when the page loads
		'show'=> true
	)
);
<?php $this->endWidget();?>
</div>
<div id="api" class="highlight" >
<p>From javascript, you can call some API to interact with your guides.</p>
<pre style="display: none"><span class="nx">guiders</span><span class="p">.</span><span class="nx">hideAll</span><span class="p">();</span> <span class="c1">// hides all guiders</span>
<span class="nx">guiders</span><span class="p">.</span><span class="nx">next</span><span class="p">();</span> <span class="c1">// hides the last shown guider, if shown, and advances to the next guider</span>
<span class="nx">guiders</span><span class="p">.</span><span class="nx">show</span><span class="p">(</span><span class="nx">id</span><span class="p">);</span> <span class="c1">// shows the guider, given the id used at creation</span>
</pre>
</div>

<h2>Customize Buttons</h2>
<p>You can define your own handler for buttons included in the Guide. This can brgin some interaction with the user : you don't
have to Guide a passive user ! let's make him work a little !
</p>
<div id="sampleCode2">
<?php 
$this->beginWidget('system.web.widgets.CTextHighlighter',array(
	'language'=>'PHP',
	'showLineNumbers'=>false,
));
?>
$this->widget('ext.eguiders.EGuider', array(
		'id'=> 'second',
		'title'=> 'Simple API',
		'next' => 'third',
		'buttons' => array(
			array(
				'name'=>'Previous',
				'onclick'=> "js:function(){guiders.hideAll(); $('.highlight pre').hide(); guiders.show('sample');}"
			),
			array(
				'name'=>'Show me more',
				'onclick'=> "js:function(){guiders.next();}"
			),
			array(
				'name'=>'Exit',
				'onclick'=> "js:function(){guiders.hideAll();}"
			)
		),
		// why not call renderPartial to get the content of the Guide ? .. yeah, why not ?
		'description' => $this->renderPartial('_guide_api',null,true),
		'overlay'=> false,
		// you can attach your guide to any element in the page thanks to JQuery selectors
		'attachTo' => '#elementId',
		'position' => 11,
		'xButton'=>true,		
		'onShow' => 'js:function(){ $(".highlight pre").show();}'
	)
);
<?php $this->endWidget();?>
</div>


<h2>Use your own style !</h2>
<p>By setting both the 'classString' and 'cssFile' options, you can customize the style of your guider.</br>
It is important to understand that in all Guiders included into a page, share the same CSS files, so if you
delcare a stylesheet on the first guide of your page, no need to declare it for other guides in the same page.<br/>
Another point is that even if you declare a custom stylesheet, <b>the default CSS file provided with the Guiders JQuery
plugin is always included</b> : your custom stylesheet must overloads it and redefine styles you want to change.
</p>

<div id="sampleCode3">
<?php 
$this->beginWidget('system.web.widgets.CTextHighlighter',array(
	'language'=>'PHP',
	'showLineNumbers'=>false,
));
?>
$this->widget('ext.eguiders.EGuider', array(
		'id'=> 'style',
		'title'=> "Custom style is also available !",
		'next'=> 'end',
		'description' => "<b>Yes you can !</b> ... Simply register your own CSS style and choose a CSS class name "
		." that will be added to the parent enclosing DIV.",
		'classString' => 'custom',
		'buttons' => array(array('name'=>'Next')),
		// remember that this CSS is going to overloads the default one,
		// not replace it !!
		'cssFile'=> Yii::app()->baseUrl. '/css/custom_guiders.css',
		'classString' => 'custom',
	)
);
<?php $this->endWidget();?>
</div>

<p>There's a lot more on using the <b>Guiders</b> plugin, so have a look at the official <a href="https://github.com/jeff-optimizely/Guiders-JS">Project page</a></p>
